import re
import unicodedata

def slugify(text: str) -> str:
    """Convierte un texto en un slug URL-safe (minúsculas, -)."""
    # Normaliza y quita acentos
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    text = text.lower()
    # Reemplaza no alfanumérico por guiones
    text = re.sub(r"[^a-z0-9]+", "-", text).strip("-")
    # Evita guiones duplicados
    text = re.sub(r"-{2,}", "-", text)
    return text
