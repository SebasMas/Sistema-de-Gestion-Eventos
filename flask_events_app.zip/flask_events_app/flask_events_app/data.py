from datetime import datetime

# Categorías sugeridas
categories = ['Tecnología', 'Académico', 'Cultural', 'Deportivo', 'Social']

# Datos en memoria (se reinician al reiniciar el servidor)
events = [
    {
        'id': 1,
        'title': 'Conferencia de Python',
        'slug': 'conferencia-de-python',
        'description': 'Charlas introductorias y avanzadas sobre el ecosistema Python.',
        'date': '2025-09-15',
        'time': '14:00',
        'location': 'Auditorio Principal',
        'category': 'Tecnología',
        'max_attendees': 50,
        'attendees': [
            {'name': 'Juan Pérez', 'email': 'juan@example.com'}
        ],
        'featured': True
    }
]

def parse_event_dt(event):
    """Devuelve datetime a partir de 'date' (YYYY-MM-DD) y 'time' (HH:MM)."""
    return datetime.strptime(f"{event['date']} {event['time']}", "%Y-%m-%d %H:%M")
