from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, DateField, TimeField, IntegerField, BooleanField, SubmitField, SelectField
from wtforms.validators import DataRequired, Length, NumberRange, Email
from data import categories

class EventForm(FlaskForm):
    title = StringField('Título', validators=[DataRequired(), Length(max=120)])
    description = TextAreaField('Descripción', validators=[DataRequired(), Length(max=5000)])
    date = DateField('Fecha', format='%Y-%m-%d', validators=[DataRequired()])
    time = TimeField('Hora', format='%H:%M', validators=[DataRequired()])
    location = StringField('Ubicación', validators=[DataRequired(), Length(max=200)])
    category = SelectField('Categoría', choices=[(c, c) for c in categories], validators=[DataRequired()])
    max_attendees = IntegerField('Cupo máximo', validators=[DataRequired(), NumberRange(min=1, max=100000)])
    featured = BooleanField('Destacado en portada')
    submit = SubmitField('Crear evento')

class RegistrationForm(FlaskForm):
    name = StringField('Nombre', validators=[DataRequired(), Length(max=120)])
    email = StringField('Email', validators=[DataRequired(), Email(), Length(max=200)])
    submit = SubmitField('Registrarme')
