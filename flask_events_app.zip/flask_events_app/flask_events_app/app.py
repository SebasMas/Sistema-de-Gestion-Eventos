from flask import Flask, render_template, url_for, redirect, request, flash, abort
from datetime import datetime, date
from data import events, categories, parse_event_dt
from forms import EventForm, RegistrationForm
from utils import slugify

app = Flask(__name__)
app.config['SECRET_KEY'] = 'dev-secret-key'  # cámbiala por una var. de entorno en producción

# ---------- Helpers ----------
def get_event_by_slug(slug: str):
    for ev in events:
        if ev['slug'] == slug:
            return ev
    return None

def ensure_unique_slug(base_title: str) -> str:
    base = slugify(base_title)
    slug = base
    counter = 2
    existing = {e['slug'] for e in events}
    while slug in existing:
        slug = f"{base}-{counter}"
        counter += 1
    return slug

def upcoming_events_only(ev_list):
    today = datetime.now()
    return [e for e in ev_list if parse_event_dt(e) >= today]

def sort_by_dt(ev_list):
    return sorted(ev_list, key=parse_event_dt)

# ---------- Routes ----------
@app.route('/')
def index():
    ups = sort_by_dt(upcoming_events_only(events))
    featured = [e for e in ups if e.get('featured')]
    non_featured = [e for e in ups if not e.get('featured')]
    return render_template('index.html', featured=featured, events=non_featured, categories=categories)

@app.route('/event/<slug>/')
def event_detail(slug):
    ev = get_event_by_slug(slug)
    if not ev:
        abort(404)
    capacity = ev['max_attendees']
    current = len(ev['attendees'])
    available = max(capacity - current, 0)
    return render_template('event_detail.html', event=ev, capacity=capacity, available=available, categories=categories)

@app.route('/admin/event/', methods=['GET', 'POST'])
def create_event():
    form = EventForm()
    if form.validate_on_submit():
        new_id = max([e['id'] for e in events], default=0) + 1
        slug = ensure_unique_slug(form.title.data)
        new_event = {
            'id': new_id,
            'title': form.title.data.strip(),
            'slug': slug,
            'description': form.description.data.strip(),
            'date': form.date.data.strftime('%Y-%m-%d'),
            'time': form.time.data.strftime('%H:%M'),
            'location': form.location.data.strip(),
            'category': form.category.data,
            'max_attendees': form.max_attendees.data,
            'attendees': [],
            'featured': bool(form.featured.data)
        }
        events.append(new_event)
        flash('Evento creado correctamente.', 'success')
        return redirect(url_for('event_detail', slug=slug))
    return render_template('event_form.html', form=form, categories=categories)

@app.route('/event/<slug>/register/', methods=['GET', 'POST'])
def register_event(slug):
    ev = get_event_by_slug(slug)
    if not ev:
        abort(404)
    form = RegistrationForm()
    capacity = ev['max_attendees']
    if len(ev['attendees']) >= capacity:
        flash('Este evento está lleno. No hay cupos disponibles.', 'warning')
        return redirect(url_for('event_detail', slug=slug))
    if form.validate_on_submit():
        name = form.name.data.strip()
        email = form.email.data.strip().lower()
        # Evitar registros duplicados por email
        if any(a['email'].lower() == email for a in ev['attendees']):
            flash('Ya estás registrado para este evento con ese email.', 'warning')
            return redirect(url_for('event_detail', slug=slug))
        ev['attendees'].append({'name': name, 'email': email})
        flash('Registro exitoso. ¡Te esperamos!', 'success')
        return redirect(url_for('event_detail', slug=slug))
    return render_template('register_form.html', form=form, event=ev, categories=categories)

@app.route('/events/category/<category>/')
def by_category(category):
    # Coincidencia case-insensitive
    filtered = [e for e in events if e['category'].casefold() == category.casefold()]
    ups = sort_by_dt(upcoming_events_only(filtered))
    return render_template('category.html', events=ups, category=category, categories=categories)

# Ejecutar con: python app.py (modo dev)
if __name__ == '__main__':
    app.run(debug=True)
